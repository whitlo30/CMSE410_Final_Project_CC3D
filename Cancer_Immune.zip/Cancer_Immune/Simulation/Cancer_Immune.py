
from cc3d import CompuCellSetup
        


from Cancer_ImmuneSteppables import ConstraintInitializerSteppable

CompuCellSetup.register_steppable(steppable=ConstraintInitializerSteppable(frequency=1))




from Cancer_ImmuneSteppables import GrowthSteppable

CompuCellSetup.register_steppable(steppable=GrowthSteppable(frequency=1))



from Cancer_ImmuneSteppables import DeathSteppable

CompuCellSetup.register_steppable(steppable=DeathSteppable(frequency=1))




from Cancer_ImmuneSteppables import MitosisSteppable

CompuCellSetup.register_steppable(steppable=MitosisSteppable(frequency=1))




from Cancer_ImmuneSteppables import CellTypePlot

CompuCellSetup.register_steppable(steppable=CellTypePlot())




from Cancer_ImmuneSteppables import MutationPlot

CompuCellSetup.register_steppable(steppable=MutationPlot())



from Cancer_ImmuneSteppables import SecretionSteppable

CompuCellSetup.register_steppable(steppable=SecretionSteppable())




from Cancer_ImmuneSteppables import ChemotaxisSteering

CompuCellSetup.register_steppable(steppable=ChemotaxisSteering())


CompuCellSetup.run()
