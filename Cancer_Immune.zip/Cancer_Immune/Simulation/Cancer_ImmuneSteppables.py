from cc3d.core.PySteppables import *
import numpy as np

# Number of immune cell clusters, used within population calculations
numCluster = 1

# Defining general constraints and cell properties
class ConstraintInitializerSteppable(SteppableBasePy):
    def __init__(self,frequency=1):
        SteppableBasePy.__init__(self,frequency)

    def start(self):

        for cell in self.cell_list:

            cell.targetVolume = 64
            cell.lambdaVolume = 8.0
            cell.dict["MutationCount"] = 0
            if (cell.type == 1):
                cell.dict["SecretionAmt"] = 10
            if cell.type == 4:
                cell.dict["ChemoLamb"] = 2.5
                cell.dict["TimeAlive"] = 0

        

# Class defining the growth of the cells      
class GrowthSteppable(SteppableBasePy):
    def __init__(self,frequency=1):
        SteppableBasePy.__init__(self, frequency)

    def step(self, mcs):
    
         field = self.field.Nutrients
         im = self.field.Immune_Secretion
        
         for cell in self.cell_list_by_type(self.PROLIFERATING):
            concentrationAtCOM = field[int(cell.xCOM), int(cell.yCOM), int(cell.zCOM)]
            immuneAtCOM = im[int(cell.xCOM), int(cell.yCOM), int(cell.zCOM)]
       
            if immuneAtCOM > 10:
                cell.type = self.NECROTIC
                cell.targetVolume = 0
            elif concentrationAtCOM < 70:
                cell.type = self.QUIESCENT
            else:
                cell.targetVolume += 0.5
                
         for cell in self.cell_list_by_type(self.QUIESCENT):
            concentrationAtCOM = field[cell.xCOM, cell.yCOM, cell.zCOM]
            immuneAtCOM = im[int(cell.xCOM), int(cell.yCOM), int(cell.zCOM)]
            if concentrationAtCOM > 70:
                cell.type = self.PROLIFERATING
            if concentrationAtCOM < 40:
                cell.type = self.NECROTIC
                cell.targetVolume = 0
            if immuneAtCOM > 5:
                cell.type = self.NECROTIC
                cell.targetVolume = 0
 
# Defining the death/expiration of immune system cells 
class DeathSteppable(SteppableBasePy):
    def __init__(self,frequency=1):
        SteppableBasePy.__init__(self, frequency)
        
    def step(self, mcs):
        
        for cell in self.cell_list_by_type(self.IMMUNE):
            cell.dict["TimeAlive"] += 1
            if cell.dict["TimeAlive"] >= 600:
                cell.type = self.NECROTIC
                cell.targetVolume = 0

# Defining the mitotic properties of all cells      
class MitosisSteppable(MitosisSteppableBase):
    def __init__(self,frequency=1):
        MitosisSteppableBase.__init__(self,frequency)

    def step(self, mcs):

        cells_to_divide=[]
        for cell in self.cell_list:
            if cell.volume>2*64:
                cells_to_divide.append(cell)

        im = self.field.Immune_Secretion
        
        # Immmune cell recruitment
        for cell in self.cell_list_by_type(self.IMMUNE):
            immuneAtCOM = im[int(cell.xCOM), int(cell.yCOM), int(cell.zCOM)]
            if (immuneAtCOM > 150) and (len(self.cell_list_by_type(self.IMMUNE)) < 100*numCluster):
                cells_to_divide.append(cell)

        for cell in cells_to_divide:
            self.divide_cell_random_orientation(cell)           
 
# Defining how properties get transfered between parent and child - including mutations 
    def update_attributes(self):
        # reducing parent target volume
        if self.parent_cell.type is not self.IMMUNE:
            self.parent_cell.targetVolume /= 2.0

        self.clone_parent_2_child()

        r = np.random.uniform(1)
        r_2 = np.random.uniform(1)
        if self.child_cell.type == self.PROLIFERATING:
            if r > 0.90:
                self.child_cell.dict["SecretionAmt"] = np.random.randint(1,50)
                self.child_cell.dict["MutationCount"] += 1
         
        if self.child_cell.type == 4:
            self.child_cell.dict["TimeAlive"] = 0

# Creation of live cell type population plots
class CellTypePlot(SteppableBasePy):
    def __init__(self, _frequency=1):
        SteppableBasePy.__init__(self,_frequency)

    def start(self):
        self.pW = self.addNewPlotWindow(
            _title='Counts by Cell Type',
            _xAxisTitle='MonteCarlo Step (MCS)',
            _yAxisTitle='Cell Count',
            _xScaleType='linear',
            _yScaleType='linear',
            _grid=True, # only in 3.7.6 or higher
            _config_options={"legend":True}
        )

        self.pW.addPlot('ProlifCount', _style='Dots', _color='grey', _size=5)
        self.pW.addPlot('ImmuneCount', _style='Dots', _color='green', _size=5)
        self.pW.addPlot('QuiescentCount', _style='Dots', _color='red', _size=5)
        self.pW.addPlot('NecroticCount', _style='Dots', _color='blue', _size=5)
    def step(self, mcs):

        numberOfProlif = len(self.cell_list_by_type(self.PROLIFERATING))
        numberOfImmune = len(self.cell_list_by_type(self.IMMUNE))
        numberOfQuiescent = len(self.cell_list_by_type(self.QUIESCENT))
        numberOfNecrotic = len(self.cell_list_by_type(self.NECROTIC))
        
        self.pW.addDataPoint("ProlifCount", mcs, numberOfProlif)  
        self.pW.addDataPoint("ImmuneCount", mcs, numberOfImmune)  
        self.pW.addDataPoint("QuiescentCount", mcs, numberOfQuiescent) 
        self.pW.addDataPoint("NecroticCount", mcs, numberOfNecrotic)  
 
# Creation of live average cancer mutation plot 
class MutationPlot(SteppableBasePy):
    def __init__(self, _frequency=1):
        SteppableBasePy.__init__(self,_frequency)

    def start(self):
        self.pW = self.addNewPlotWindow(
            _title='Mutation Counts',
            _xAxisTitle='MonteCarlo Step (MCS)',
            _yAxisTitle='Average Mutation Count',
            _xScaleType='linear',
            _yScaleType='linear',
            _grid=True, # only in 3.7.6 or higher
            _config_options={"legend":True}
        )

        self.pW.addPlot('AvgMutationCancer', _style='Dots', _color='orange', _size=5)
     
    def step(self, mcs):

        numberOfMutC = 0
        c_count = 0
        numberOfMutI = 0
        i_count = len(self.cell_list_by_type(self.IMMUNE))
        for cell in self.cell_list:
            if cell.type is not self.IMMUNE:
                numberOfMutC += cell.dict["MutationCount"]
                c_count += 1
            else:
                numberOfMutI += cell.dict["MutationCount"]
        
        if c_count != 0:
            numberOfMutC /= c_count
        if i_count != 0:
            numberOfMutI /= len(self.cell_list_by_type(self.IMMUNE))
        
        self.pW.addDataPoint("AvgMutationCancer", mcs, numberOfMutC)
        #self.pW.addDataPoint("AvgMutationImmune", mcs, numberOfMutI)
        
# Defining the change in secretion rate for mutated cancer cells       
class SecretionSteppable(SecretionBasePy):
    def __init__(self, _frequency=1):
        SecretionBasePy.__init__(self, _frequency)

    def step(self, mcs):
        cancSecretor = self.getFieldSecretor("Cancer_Secretion")
        immuneSecretor = self.getFieldSecretor("Immune_Secretion")
        for cell in self.cellList:
            if cell.type == self.PROLIFERATING:
                cancSecretor.secreteOutsideCellAtBoundary(cell, cell.dict["SecretionAmt"])
            if cell.type == self.IMMUNE:
                immuneSecretor.secreteOutsideCellAtBoundaryOnContactWith(cell,
                50, [self.PROLIFERATING])
           
        
        
# Defining the chemotactic properties of cancer cells and immune cells
class ChemotaxisSteering(SteppableBasePy):
        def __init__(self, _frequency=1):
            SteppableBasePy.__init__(self, _frequency)

        def start(self):
            for cell in self.cell_list_by_type(self.IMMUNE):
                cd = self.chemotaxisPlugin.addChemotaxisData(cell, "Cancer_Secretion")
                cd.setLambda(cell.dict["ChemoLamb"])
            for cell in self.cell_list_by_type(self.PROLIFERATING):
                cd = self.chemotaxisPlugin.addChemotaxisData(cell, "Immune_Secretion")
                cd.setLambda(-10)

        def step(self, mcs):
            for cell in self.cell_list_by_type(self.IMMUNE):
                cd = self.chemotaxisPlugin.getChemotaxisData(cell, "Cancer_Secretion")
                cd.setLambda(cell.dict["ChemoLamb"])    
    